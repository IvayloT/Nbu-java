public class Store {

}
