import java.time.LocalDate;

public class Product {
  private String id;
  private String name;
  private double purchasePrice;
  private Category category;
  private LocalDate expirationDate;

  public Product(String id, String name, double purchasePrice, Category category, LocalDate expirationDate) {
    this.id = id;
    this.name = name;
    this.purchasePrice = purchasePrice;
    this.category = category;
    this.expirationDate = expirationDate;
  }

  public enum Category {
    FOOD,
    NON_FOOD
  }

  // Getters and Setters

  public double getSalePrice(double markupPercentage, double discountPercentage, int discountDays) {
    double salePrice = this.purchasePrice * (1 + markupPercentage / 100);
    if (expirationDate.isBefore(LocalDate.now().plusDays(discountDays))) {
      salePrice *= (1 - discountPercentage / 100);
    }
    return salePrice;
  }

  public boolean isExpired() {
    return LocalDate.now().isAfter(expirationDate);
  }
}
