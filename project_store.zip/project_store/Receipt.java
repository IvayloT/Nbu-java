public class Receipt {

}
