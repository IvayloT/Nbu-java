public class StoreTests {

}
